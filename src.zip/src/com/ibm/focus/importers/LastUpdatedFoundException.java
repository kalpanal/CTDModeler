package com.ibm.focus.importers;

public class LastUpdatedFoundException extends Exception {
	public LastUpdatedFoundException(String message)
	  {
	    super(message);
	  }

}
